#include <stdio.h>

int main() {
  int x = -1;

  /**
   * codigo qualquer
  */

  if (x == 0) {
    printf("X is zero");
  }
  
  return 0;
}
