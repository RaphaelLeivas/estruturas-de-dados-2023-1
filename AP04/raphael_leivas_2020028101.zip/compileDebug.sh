echo "Cleaning make..."
make clean
echo "Make successfully cleaned. Running in dev mode..."
make dev
echo "Compile in dev successfull."
gdb /mnt/c/dev/estruturas-de-dados-2023-1/ap04/bin/AP04