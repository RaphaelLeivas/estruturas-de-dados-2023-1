#ifndef FACTORIAL_H
#define FACTORIAL_H

#include "msgassert.h"
#include <math.h>

unsigned int getRecursiveFactorial(unsigned int n);
unsigned int getIteractiveFactorial(unsigned int n);

#endif
