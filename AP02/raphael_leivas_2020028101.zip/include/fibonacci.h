#ifndef FIBONACCI_H
#define FIBONACCI_H

#include "msgassert.h"

unsigned int getRecursiveFibonacci(unsigned int n);
unsigned int getIteractiveFibonacci(unsigned int n);

#endif
